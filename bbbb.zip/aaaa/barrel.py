import pygame


class Barrel(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("images/barrel.png")
        self.image = pygame.transform.scale(self.image, (100, 100))
        self.rect = self.image.get_rect(center=(x,y))
        self.exploded = False
        self.explosion_radius = 150
        self.explosion_duration = 90


    def draw_explosion(self, screen):
        if self.exploded and self.explosion_duration > 0:
            explosion_surface = pygame.Surface((self.explosion_radius * 2, self.explosion_radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(explosion_surface, (255, 165, 0, 150),
                               (self.explosion_radius, self.explosion_radius),
                               self.explosion_radius)
            screen.blit(explosion_surface,
                        (self.rect.centerx - self.explosion_radius,
                         self.rect.centery - self.explosion_radius))
    def get_explosion_area(self):
        return pygame.Rect(self.rect.centerx - self.explosion_radius
                           , self.rect.centery - self.explosion_radius
                           , self.explosion_radius * 2
                           , self.explosion_radius * 2)